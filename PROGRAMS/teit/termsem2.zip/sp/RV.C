#include<stdio.h>
#include<conio.h>
void main()
{
 char a=10,b=20,c;
 c=a+b;
 printf("%d",c);
 getch();
}

